# ShotgunGame
Assignment task 2, a game of shotgun
